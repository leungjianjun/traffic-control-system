package com.yogng.client.test.YOG;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
	LoginTest.class,
	MyGridViewAdapterTest.class,
	MainAcitivityTest.class
})
public class YOGTestSuite {
	
}
