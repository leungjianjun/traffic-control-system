package com.yogng.client.YOG;

import java.io.IOException;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.yogng.client.YOG.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends Activity {
	  private Button ensure;
	  private Button cancel;
	  private EditText accountEdit;
	  private EditText passwordEdit;
	  private TextView accountView;
	  private TextView passwordView;
	  
	  private String URL;
	  private String account;
	  private String password;
	  private String sessionId;
	  
	  
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*---------------------------加载loginmain.xml Layout--------------------------------------*/
        setContentView(R.layout.loginmain);
        
     /*----------------------登陆------------------------*/   
        accountEdit=(EditText) findViewById(R.id.edit01);
        passwordEdit=(EditText) findViewById(R.id.edit02);
        ensure= (Button) findViewById(R.id.button01);
        cancel= (Button) findViewById(R.id.button02);
        accountView=(TextView) findViewById(R.id.textview01);
        passwordView=(TextView) findViewById(R.id.textview02);
        
        ensure.setOnClickListener(new Button.OnClickListener()
        { 
          public void onClick(View v) 
          { 
        	account=accountEdit.getText().toString();
            password=passwordEdit.getText().toString();
            
            
/*-------------------------------发送登陆请求，获取session----------------------------------*/
            URL="http://192.168.253.123:8080/YOGNG/clientlogin?user_account=" +
            account+"&user_password="+password; 
            
            sessionId=sendMessage(URL);
            
            
        	
/*----------------------------如果session=N则提示是否退出程序或再试一次-------------------------------------*/
            
            if(sessionId.equals("N")){
            	new AlertDialog.Builder(Login.this)
                .setTitle(R.string.app_title)
                .setMessage(R.string.app_about_errormsg)
                .setPositiveButton(R.string.str_out,
                new DialogInterface.OnClickListener()
              {
               public void onClick(DialogInterface dialoginterface, int i)
               {           
                   System.exit(0);
               }
               }
              )
                .setNegativeButton(R.string.str_again,
                 new DialogInterface.OnClickListener()
                {
               public void onClick(DialogInterface dialoginterface, int i)   
              {
            	   accountEdit.setText("");
            	   passwordEdit.setText("");
            	   
              }
                })
              .show();
            }
            else  {
            	//否则跳转页面
            	Intent intent = new Intent(); 
                intent.setClass(Login.this,MainActivity.class); 
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                Bundle bundle = new Bundle();
                bundle.putString("account",account);
                bundle.putString("password",password); 
                bundle.putString("sessionId",sessionId); 
                
                intent.putExtras(bundle); 
 
                startActivity(intent); 
                Login.this.finish();
            } 
/*--------------------------------------------------------------------------------*/            
            }
          });
        
        cancel.setOnClickListener(new Button.OnClickListener()
        { 
          public void onClick(View v) 
          { 
        	  new AlertDialog.Builder(Login.this)      
              .setTitle(R.string.app_title)
              .setMessage(R.string.app_about_msg)
              .setPositiveButton(R.string.str_ok,
              new DialogInterface.OnClickListener()
            {
             public void onClick(DialogInterface dialoginterface, int i)
             {           
                 System.exit(0);
             }
             }
            )
              .setNegativeButton(R.string.str_no,
               new DialogInterface.OnClickListener()
              {
             public void onClick(DialogInterface dialoginterface, int i)   
            {
            }
              })
            .show();
            } 
          });
       
    }

   
public String sendMessage(String url) {
    	String returnMessage = null;
    /*--------------------------------------发送GET请求-------------------------------------------------*/
        	
    	HttpGet httpRequest = new HttpGet(url);
        try{
        	HttpResponse httpResponse=new DefaultHttpClient().execute(httpRequest);
        	/*状态码=200?*/
        	if(httpResponse.getStatusLine().getStatusCode() == 200)
        	{
        		returnMessage=EntityUtils.toString(httpResponse.getEntity());
        	}
        }
        catch(ClientProtocolException e){
        	e.printStackTrace();
        }
        catch(IOException e){
        	e.printStackTrace();
        }
        catch(Exception e){
        	e.printStackTrace();
        }
    	return returnMessage;
    }
public boolean onCreateOptionsMenu(Menu menu)
{
	
	menu.add(0, 0, 0, R.string.str_about);
	menu.add(0, 1, 1, R.string.str_out);
	return true;
}
public void onBackPressed() {
	new AlertDialog.Builder(Login.this)      
    .setTitle(R.string.app_title)
    .setMessage(R.string.app_about_msg)
    .setPositiveButton(R.string.str_ok,
    new DialogInterface.OnClickListener()
  {
   public void onClick(DialogInterface dialoginterface, int i)
   {         
  	 
  	 System.exit(0);
   }
   }
  )
    .setNegativeButton(R.string.str_no,
     new DialogInterface.OnClickListener()
    {
   public void onClick(DialogInterface dialoginterface, int i)   
  {
  }
    })
  .show();
	return;
	}

public boolean onOptionsItemSelected(MenuItem item)
{

	int item_id = item.getItemId();

	switch (item_id)
	{
		case 0:
			Intent intent =new Intent();
			intent.setClass(Login.this,About.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	        startActivity(intent); 
			break;
		case 1:
			new AlertDialog.Builder(Login.this)      
	          .setTitle(R.string.app_title)
	          .setMessage(R.string.app_about_msg)
	          .setPositiveButton(R.string.str_ok,
	          new DialogInterface.OnClickListener()
	        {
	         public void onClick(DialogInterface dialoginterface, int i)
	         {           
	             System.exit(0);
	         }
	         }
	        )
	          .setNegativeButton(R.string.str_no,
	           new DialogInterface.OnClickListener()
	          {
	         public void onClick(DialogInterface dialoginterface, int i)   
	        {
	        }
	          })
	        .show();
			break;
	}
	return true;
}
   
    
}