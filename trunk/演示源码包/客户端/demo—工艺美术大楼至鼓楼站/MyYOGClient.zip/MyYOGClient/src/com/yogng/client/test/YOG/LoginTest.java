package com.yogng.client.test.YOG;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yogng.client.YOG.*;
public class LoginTest {
	@Test
	public void testSendMessage(){
		Login login=new Login();
		assertEquals(login.sendMessage("http://192.168.253.112:8080/YOGNG/clientlogin?user_account=test&user_password=12345"), "N");
	}
	
}
