package com.yogng.client.test.YOG;


import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.yogng.client.YOG.*;

import org.junit.Test;

public class MainAcitivityTest {
	@Test
	public void test_sendMessage(){
		MainActivity mainActivity=new MainActivity();
		assertEquals(mainActivity.sendMessage("http://192.168.253.112:8080/YOGNG/receiver;jsessionid=1?latlng=32,108&time=12:23:23"),"N");
	}
	
	@Test
	public void testGetTime(){
		MainActivity mainActivity=new MainActivity();
		assertEquals(mainActivity.getTime("HH"),new SimpleDateFormat("HH").format(new Date()));
		assertEquals(mainActivity.getTime("mm"),new SimpleDateFormat("mm").format(new Date()));
		assertEquals(mainActivity.getTime("ss"),new SimpleDateFormat("ss").format(new Date()));
	}
}
