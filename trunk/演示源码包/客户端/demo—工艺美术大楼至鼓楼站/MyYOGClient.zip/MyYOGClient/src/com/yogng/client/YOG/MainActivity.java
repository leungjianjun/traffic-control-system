﻿package com.yogng.client.YOG;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.yogng.client.YOG.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SlidingDrawer;

public class MainActivity extends Activity{
	
	  //private String GPSFile="nju2gulouzhan.txt";     //要打开的路线文件
	  //private String[] locationDemo=new String[1];
	  private ArrayList<String> locationDemo=new ArrayList<String>();
	  private int indexForDemo=0;
	  
	  private GridView gv;
	  private SlidingDrawer sd;
	  private ImageView im;
	  
	  private JSONObject json; 
	  
	  private Handler handler=new Handler(){
		  public void handleMessage(Message msg){
			  switch(msg.what){
			  case 0x000001:
				  GO();
				  break;
			  }
			  super.handleMessage(msg);
		  }
	  };
	  private Timer  mTimer= new Timer(true); 
	  private int MSG=0x000001;
	  private TimerTask mTimerTask=new TimerTask(){
			
			public void run() {
					Message message=new Message();
					message.what=MSG;
					handler.sendMessage(message);
				return;
			}
	  };
	  private int[] icons={R.drawable.divide,R.drawable.divide,
	                       R.drawable.divide,R.drawable.divide,
	                       R.drawable.divide,R.drawable.divide,
	                       R.drawable.divide,R.drawable.divide};
	  
	  
	  
	  private WebView myWebView;
	  private MyGridViewAdapter adapter;
	  
	  
	  private String[] items={"用户名：xxxx","起点：xxxx","终点：xxxx",
	                          "经过点：xxxx","剩余时间：xxxx",
	                          "剩余路程：xxxx","当前速度：xxxx",
	                          "提醒信息：xxxx"};   
	  private String account;
	  private String password;
	  private String sessionId;
	  private Location location;
	  private String URL;
	  private LocationManager locationManager;
	  private String provider=LocationManager.NETWORK_PROVIDER;
	  
	  
   public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
/*---------------------------加载main.xml Layout--------------------------------------*/
		setContentView(R.layout.main);
		 
        Initialize();//初始化组件和值
        
	    GoMap();//显示地图

  
/*-----------------------------------获取GPS------------------------------------------------*/
	    
	    String serviceName=Context.LOCATION_SERVICE;
	    /*-----------------------------获得LocationManager实例----------------------*/
	    locationManager=(LocationManager) getSystemService(serviceName);
	    /*-----------------------------使用GPS定位技术-------------------*/
	    	    
/*-----------------------------------------------------------------------------------*/	 	    

		/*updateWithNewLocation(location);
		
		try {
			json=new JSONObject(sendMessage(URL));
			items[0]="用户名："+json.getString("user_name");
			items[3]="当前速度"+json.getString("speed");
			items[5]="提示信息"+json.getString("message");

		} catch (JSONException e) {
			e.printStackTrace();
		}*/
		

/*-------------------------- 设置SlidingDrawer被打开的事件处理----------------------------------- */
	    sd.setOnDrawerOpenListener(new SlidingDrawer.OnDrawerOpenListener()
	    {
	      @Override
	      public void onDrawerOpened()
	      {
	        im.setImageResource(R.drawable.close);
	      }
	    });
/*-------------------------- 设置SlidingDrawer被关闭的事件处理----------------------------------- */
	    sd.setOnDrawerCloseListener(new SlidingDrawer.OnDrawerCloseListener()
	    {
	      @Override
	      public void onDrawerClosed()
	      {
	        im.setImageResource(R.drawable.open);
	      }
	    });
		
}

private void Initialize() {
	
/*---------------------------通过Bundle来获取账号密码sessionId----------------------*/		
	Bundle bunde = this.getIntent().getExtras();
	account= bunde.getString("account");
	password= bunde.getString("password");
	sessionId= bunde.getString("sessionId");
	items[0]="用户名："+account;
		
/*---------------------------初始化对象------------------------------------------------ */
    gv = (GridView)findViewById(R.id.myContent1);
    sd = (SlidingDrawer)findViewById(R.id.drawer1);
    im=(ImageView)findViewById(R.id.myImage1);
    
/*-----------------------------------透明化处理----------------------------------------------*/
    gv.getBackground().setAlpha(150);
    sd.getBackground().setAlpha(0);
    im.getBackground().setAlpha(0);
    View layout=findViewById(R.id.layout1);
    layout.getBackground().setAlpha(0);	   
/*----------使用自定义的MyGridViewAdapter设置GridView里面的item内容----------------------- */
    adapter=new MyGridViewAdapter(this,items,icons);
    gv.setAdapter(adapter);    

    	    
}

private void GoMap() {
	
/*---------------------------设置WebView的对象------------------------------------------*/
    myWebView=(WebView)findViewById(R.id.myWebView);
    WebSettings webSettings=myWebView.getSettings();
    webSettings.setJavaScriptEnabled(true);
    myWebView.setWebChromeClient(new WebChromeClient());
/*---------------------------翻译JavaScript-------------------------------------------------*/    
    
    String strIFrame="<iframe name=\"Hippo_imageNote_frame\""+
                     "width=\"320\"height=\"480\""+
                     "frameborder=\"0\"src="+
                     "\"http://192.168.253.123:8080/YOGNG/clientmap.jsp?user_account=" +
                 account+"&user_password="+password+ 
                                                      "\""+              //这里的地址是固定的
                                                                           //为了显示地图
                     "marginwidth=\"0\" marginheight=\"0\"vspace=\"0\" "+
                     "scrolling=\"no\"></iframe>";
    myWebView.loadData("<html><body>"+strIFrame+"</body></html>", "text/html", "utf-8"); 
    
}

public String sendMessage(String url) {
		String returnMessage = null;
/*--------------------------------------发送GET请求----------------------------------------*/
	    	
		HttpGet httpRequest = new HttpGet(url);
	    try{
	    	HttpResponse httpResponse=new DefaultHttpClient().execute(httpRequest);
	    	/*状态码=200?*/
	    	if(httpResponse.getStatusLine().getStatusCode() == 200)
	    	{
	    		returnMessage=EntityUtils.toString(httpResponse.getEntity());
	    	}
	    }
	    catch(ClientProtocolException e){
	    	e.printStackTrace();
	    }
	    catch(IOException e){
	    	e.printStackTrace();
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    }
		return returnMessage;
	}

private void updateWithNewLocation(Location location) {
	    location=locationManager.getLastKnownLocation(provider);
		String lats =""+32,lngs =""+108;
		if(location!=null){
	    	lats=""+location.getLatitude();//纬度
	    	lngs=""+location.getLongitude();//经度
	    }
		
		URL="http://192.168.253.123:8080/YOGNG/receiver;jsessionid=" +
		    sessionId+"?latlng=" 
	        +lats+","+lngs+"&time=" +
	        getTime("HH")+":"+getTime("mm")+":"+getTime("ss");
		//items[6]="纬度:"+lats;
		//items[7]="经度:"+lngs;
	    }

public boolean onCreateOptionsMenu(Menu menu)
	{
		
		menu.add(0, 0, 0, R.string.str_start);
		menu.add(0, 1, 1, R.string.str_arrive);
		menu.add(0, 2, 2, R.string.str_about);
		menu.add(0, 3, 3, R.string.str_out);
		return true;
	}


public boolean onOptionsItemSelected(MenuItem item)
	{

		int item_id = item.getItemId();

		switch (item_id)
		{
			case 2:
				Intent intent =new Intent();
				intent.setClass(MainActivity.this,About.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		        startActivity(intent);
				break;
			case 1:
				mTimer.cancel();//停止循环
				URL="http://192.168.253.123:8080/YOGNG/receiver;jsessionid=" +
			    sessionId+"?latlng=end&time=" +
		        getTime("HH")+":"+getTime("mm")+":"+getTime("ss");
				try {
					
					json=new JSONObject(sendMessage(URL));
					items[0]="用户名："+json.getString("user_name");
					items[1]="起点："+json.getString("st_p");
					items[2]="终点："+json.getString("ed_p");
					items[4]="剩余时间"+json.getString("time_remain");
					items[5]="剩余路程"+json.getString("route_remain");
					items[6]="当前速度"+json.getString("current_speed");
					items[7]="提醒信息"+json.getString("message");
					if(json.getJSONArray("waypoints")!=null){
						JSONArray array=json.getJSONArray("waypoints");
						items[3]="经过点:";
						for(int i =0;i< array.length();i++){
							items[3]+=array.getJSONObject(i).getString("waypoint");
						}
					}else{
						items[3]="经过点：无";
					}
				} catch (JSONException e) {
					e.printStackTrace();
					items[3]="经过点：无";
				}
				adapter=new MyGridViewAdapter(this,items,icons);
				System.gc();
				gv.setAdapter(adapter);
			    
				break;
			case 3:
				new AlertDialog.Builder(MainActivity.this)      
		          .setTitle(R.string.app_title)
		          .setMessage(R.string.app_about_msg)
		          .setPositiveButton(R.string.str_ok,
		          new DialogInterface.OnClickListener()
		        {
		         public void onClick(DialogInterface dialoginterface, int i)
		         {         
		        	 
		        	 System.exit(0);
		         }
		         }
		        )
		          .setNegativeButton(R.string.str_no,
		           new DialogInterface.OnClickListener()
		          {
		         public void onClick(DialogInterface dialoginterface, int i)   
		        {
		        }
		          })
		        .show();
			    break;
			case 0:
				/*
				 * 测试用代码
				 * 
				 * -----------*/
				readGPSFile(this);
				/*--------------*/
				
				
				
		/*---------------------开始循环发送--------------------------------*/        		
			    mTimer.schedule(mTimerTask,5000,1000);
			    
		}
		return true;
	}
public void onBackPressed() {
	new AlertDialog.Builder(MainActivity.this)      
    .setTitle(R.string.app_title)
    .setMessage(R.string.app_about_msg)
    .setPositiveButton(R.string.str_ok,
    new DialogInterface.OnClickListener()
  {
   public void onClick(DialogInterface dialoginterface, int i)
   {         
  	 
  	 System.exit(0);
   }
   }
  )
    .setNegativeButton(R.string.str_no,
     new DialogInterface.OnClickListener()
    {
   public void onClick(DialogInterface dialoginterface, int i)   
  {
  }
    })
  .show();
	return;
	}


public String getTime(String format){
/*-------------------------------获取当前时间---------------------------------*/
			String CurrentTime = null;
			SimpleDateFormat sdf1=new SimpleDateFormat(format);
			CurrentTime=sdf1.format(new Date());
			return CurrentTime;
	}

private void GO(){
/*-------------------------------------循环实体----------------------------------*/
//		获取GPS和时间
//		updateWithNewLocation(location);
/*-----------------------------------<for demo----------------------------------------------*/
	URL="http://192.168.253.123:8080/YOGNG/receiver;jsessionid="+sessionId+"?latlng="
    +locationDemo.get(indexForDemo).toString()+"&time="+getTime("HH")+":"+getTime("mm")+":"+getTime("ss");
	indexForDemo++;
	/*-----------------------------------/>-----------------------------------------------------*/
		try {
			
			json=new JSONObject(sendMessage(URL));
			items[0]="用户名："+json.getString("user_name");
			items[1]="起点："+json.getString("st_p");
			items[2]="终点："+json.getString("ed_p");
			items[4]="剩余时间"+json.getString("time_remain");
			items[5]="剩余路程"+json.getString("route_remain");
			items[6]="当前速度"+json.getString("current_speed");
			items[7]="提醒信息"+json.getString("message");
			if(json.getJSONArray("waypoints")!=null){
				JSONArray array=json.getJSONArray("waypoints");
				items[3]="经过点:";
				for(int i =0;i< array.length();i++){
					items[3]+=array.getJSONObject(i).getString("waypoint");
				}
			}else{
				items[3]="经过点：无";
			}
		} catch (JSONException e) {
			e.printStackTrace();
			items[3]="经过点：无";
		}
		
    
/*----------修改GridView和adapter里面的item内容----------------------- */
		
		adapter=new MyGridViewAdapter(this,items,icons);
		System.gc();
		gv.setAdapter(adapter);
	    
	 }

private void readGPSFile(Context context){

	String line =null;

//	int i=0;
	try{

    	InputStream inputStream = this.getResources().openRawResource(R.raw.gongyinanjing2gulouzhan);
		BufferedReader bf = new BufferedReader(new InputStreamReader(inputStream));
		while((line=bf.readLine())!=null){

			//locationDemo.[i++]=line;
			locationDemo.add(line);
			bf.readLine();
		}
		bf.close();
	}catch(FileNotFoundException e){
		e.printStackTrace();
	}catch(IOException e){
		e.printStackTrace();
	}
	locationDemo.add("end");
}

}
