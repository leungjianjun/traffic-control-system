package com.yogng.client.test.YOG;


import org.junit.Test;
import static org.junit.Assert.*;


import com.yogng.client.YOG.MainActivity;
import com.yogng.client.YOG.MyGridViewAdapter;
import com.yogng.client.YOG.R;

public class MyGridViewAdapterTest {
	  public String[] _items={"demo0","demo1","demo2","demo3","demo4","demo5"};
	  public int[] _icons={R.drawable.divide,R.drawable.divide,
                           R.drawable.divide,R.drawable.divide,
                           R.drawable.divide,R.drawable.divide,
                           R.drawable.divide,R.drawable.divide};
	  private MainActivity mainAcitivity=new MainActivity();
	  private MyGridViewAdapter adapter=new MyGridViewAdapter(mainAcitivity,_items,_icons);
	  @Test
	  public void testGetCount(){
		  assertEquals(adapter.getCount(),6);
	  }
	  
	  @Test
	  public void testGetItem(){
		  assertEquals(adapter.getItem(0),_items[0]);
		  assertEquals(adapter.getItem(1),_items[1]);
		  assertEquals(adapter.getItem(2),_items[2]);
		  assertEquals(adapter.getItem(3),_items[3]);
		  assertEquals(adapter.getItem(4),_items[4]);
		  assertEquals(adapter.getItem(5),_items[5]);
	  }
	  
	  @Test
	  public void testGetItemId(){
		  assertEquals(adapter.getItemId(0),0);
		  assertEquals(adapter.getItemId(1),1);
		  assertEquals(adapter.getItemId(2),2);
		  assertEquals(adapter.getItemId(3),3);
		  assertEquals(adapter.getItemId(4),4);
		  assertEquals(adapter.getItemId(5),5);
	  }
}
